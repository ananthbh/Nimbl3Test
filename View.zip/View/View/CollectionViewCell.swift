//
//  CollectionViewCell.swift
//  View
//
//  Created by Ananth Bhamidipati on 11/08/16.
//  Copyright © 2016 Ananth Bhamidipati. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {

    @IBOutlet var NameLabel: UILabel!
    @IBOutlet var DescLabel: UILabel!
    @IBOutlet var coverimage: UIImageView!
    
}
