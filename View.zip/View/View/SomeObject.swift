//
//  SomeObject.swift
//  View
//
//  Created by Ananth Bhamidipati on 11/08/16.
//  Copyright © 2016 Ananth Bhamidipati. All rights reserved.
//

import Foundation

class SomeObject {
    
    var naame: String!
    var description: String!
    var images: String!
    
}
